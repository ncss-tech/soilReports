ghr <- list(
  n = c("Ap", 
        "A", 
        "Bw", 
        "C", 
        "Cg", 
        "Ab", 
        "2Bt", 
        "missing"),
  
  p = c("Ap|AP",
        "^A$|A1|A2|A3",
        "^B", 
        "C",
        "Cg",
        "Ab",
        "2Bt",
        "missing")
  )
