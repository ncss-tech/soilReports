ghr <- list(
  n = c("Ap", 
        "Bt", 
        "2Btb",
        "E", 
        "Btx", 
        "C"),
  
  p = c("A",
        "^Bt|^BT|1Bt|1B t",
        "b|2Bt|3Bt",
        "E|e",
        "x|X",
        "C")
  )
