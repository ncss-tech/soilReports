ghr <- list(
  n = c("C",
        "A",
        "BAk",
        "Bk",
        "Bkkq", 
        "Bkq"),
  
  p = c("C",
        "A",
        "BAk", 
        "Bk", 
        "Bkk|B'kk", 
        "Bkq")
  )