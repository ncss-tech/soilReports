ghr <- list(
  n = c("Ap",
        "E",
        "Bt",
        "Btg",
        "C"),
  
  p = c("^A|1A",
        "E",
        "B",
        "G|g",
        "C")
  )
