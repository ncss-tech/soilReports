ghr <- list(
  n = c("Ap", 
        "Bt", 
        "BC", 
        "Cd"),
  
  p = c("A",
        "Bt|B t|B2T|B3T|BT|B22|B21",
        "BC|CB",
        "^C|1C")
  )
