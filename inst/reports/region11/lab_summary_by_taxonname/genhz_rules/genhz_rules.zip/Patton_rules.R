ghr <- list(
  n = c("Ap", 
        "Bg", 
        "Cg", 
        "missing"),
  
  p = c("^A|1A",
        "^1B g|^B",
        "1C g|^2C|^C",
        "Eg|^H|missing")
  )