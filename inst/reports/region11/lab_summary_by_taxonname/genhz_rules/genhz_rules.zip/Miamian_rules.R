ghr <- list(
  n = c("A", 
        "Ap", 
        "E", 
        "Bt",
        "2Bt",
        "2BC",
        "2Cd", 
        "missing"),
  
  p = c("A", 
        "p|P", 
        "E", 
        "BE", 
        "t|T", 
        "2Bt|IIBt",
        "BC|B3",
        "^C|2C|IIC|3C",
        "missing")
  )