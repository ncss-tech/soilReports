ghr <- list(
  n = c("A",
        "Ap", 
        "E", 
        "Bt", 
        "2Bt", 
        "2BCt",
        "2Cd"),
  
  p = c("A",
        "Ap|AP|A p",
        "E", 
        "T|t",
        "2B",
        "BC|CB|B3",
        "2C|d")
  )