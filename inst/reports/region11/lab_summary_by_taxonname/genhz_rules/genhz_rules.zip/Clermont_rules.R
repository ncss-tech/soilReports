ghr <- list(
  n = c("Ap", 
        "Btg",
        "Eg", 
        "BEt", 
        "2C"),
  
  p = c("A",
        "B",
        "E|A2|A3",
        "EB|BE|/E|B1",
        "C")
  )
